import React from 'react'

export default function Appointment() {
  return (
    <div>
      
    </div>
  )
}
