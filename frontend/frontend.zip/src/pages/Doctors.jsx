import React from 'react'

const Doctors = () => {
  return (
    <div>
      
    </div>
  )
}

export default Doctors
