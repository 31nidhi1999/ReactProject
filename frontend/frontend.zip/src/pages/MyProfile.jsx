import React from 'react'

const MyProfile = () => {
  return (
    <div>
      
    </div>
  )
}

export default MyProfile
